# -*- coding: utf-8 -*-

'''
Module
    ${MOD}.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines class ${MODLC} with attribute(s) and method(s).
    Defines model ${MODLC}.
'''

import sys
from typing import List

try:
    from app_server.models.model_base import Base
except ImportError as error:
    # Force close python ATS ##################################################
    sys.exit(f'\n{__file__}\n{error}\n')

__author__ = 'Vladimir Roncevic'
__copyright__ = '(C) ${YEAR}, Free software to use and distributed it.'
__credits__: List[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'GNU General Public License (GPL)'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${MODLC}(Base):
    '''
        Defines class ${MODLC} with attribute(s) and method(s).
        Defines model ${MODLC}.

        It defines:

            :attributes:
                | __tablename__ - Database table name.
            :methods:
                | __init__ - Initials ${MOD} constructor.
                | get_id - Gets id.
                | __repr__ - Printable representation of the ${MOD}.
    '''

    __tablename__ = '${MODLC}'

    def __init__(self, verbose: bool = False):
        '''
            Initials ${MOD} constructor.

            :param verbose: Enable/Disable verbose option
            :type verbose: <bool>
            :exceptions: None
        '''
        pass

    def get_id(self):
        '''
            Gets id from table.

            :return: Table id
            :type: <int>
        '''
        return self.id

    def __repr__(self):
        '''
            Printable representation of the ${MOD}.

            :return: Printable representation of the ${MOD}
            :type: <str>
        '''
        pass
