# -*- coding: utf-8 -*-

'''
Module
    base_model.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines class Base with attribute(s) and method(s).
    Abstract data model.
'''

import sys
from typing import List

try:
    from sqlalchemy.ext.declarative import declarative_base
    from sqlalchemy import Column, Integer, DateTime
except ImportError as error:
    # Force close python ATS ##################################################
    sys.exit(f'\n{__file__}\n{error}\n')

__author__ = 'Vladimir Roncevic'
__copyright__ = '(C) ${YEAR}, Free software to use and distributed it.'
__credits__: List[str] = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'GNU General Public License (GPL)'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'

ModelBase = declarative_base()


class Base(ModelBase):
    '''
        Defines class Base with attribute(s) and method(s).
        Abstract data model.

        It defines:

            :attributes:
                | __abstract__ - Setting abstract.
                | id - Table id.
                | created - Date of creation.
                | modified - Date of modification.
            :methods:
                | None
    '''

    __abstract__ = True
    id: Column = Column(Integer, primary_key=True, autoincrement=True)
    created: Column = Column(DateTime, nullable=False)
    modified: Column = Column(DateTime, nullable=False)
